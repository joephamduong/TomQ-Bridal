# TomQ Bridal — Website & Try-On AI

Website đặt lịch hẹn, bán áo cưới cô dâu / vest chú rể và "thử đồ AI" (khách tải ảnh toàn thân lên,
AI dựng ảnh khách mặc thử mẫu áo đã chọn) cho thương hiệu **TomQ Bridal**, kèm trang quản trị
(Admin) đầy đủ để tự vận hành mà không cần sửa code.

Website được xây song ngữ Việt / Anh, và thiết kế để **chỉ cần cài Node.js rồi chạy** trên bất kỳ
hosting nào — không phụ thuộc dịch vụ đám mây ngoài, không cần cấu hình database server riêng.

---

## 1. Công nghệ sử dụng

- **Next.js 16** (App Router) + **TypeScript** + **React 19** + **Tailwind CSS v4**
- **`node:sqlite`** — database SQLite tích hợp sẵn trong Node.js (>= 22.5), không cần cài đặt
  driver hay dịch vụ database rời, không cần build native module. Dữ liệu lưu trong 1 file
  `data/app.db` duy nhất.
- Xác thực Admin bằng JWT + cookie (không phụ thuộc dịch vụ đăng nhập ngoài).
- Trình soạn thảo bài viết Blog / mô tả sản phẩm dùng Tiptap (hỗ trợ H2/H3, chèn ảnh, chuẩn SEO).
- Giỏ hàng lưu ở trình duyệt khách (localStorage qua Zustand).

## 2. Yêu cầu hệ thống

- **Node.js phiên bản 22.5 trở lên** (bắt buộc, vì dùng `node:sqlite`). Kiểm tra bằng `node -v`.
- Hosting/VPS cho phép chạy tiến trình Node.js liên tục (không phải hosting PHP/shared hosting
  thông thường). Ví dụ: VPS Linux (Ubuntu), Railway, Render, DigitalOcean App Platform, hoặc máy
  chủ nội bộ.

## 3. Cài đặt & chạy thử

```bash
# 1. Cài dependencies
npm install

# 2. Tạo file .env từ mẫu và chỉnh sửa nếu cần (xem mục 4 bên dưới)
cp .env.example .env

# 3. Build bản production
npm run build

# 4. (Tuỳ chọn) Nạp dữ liệu mẫu TomQ Bridal — sản phẩm, blog, khách hàng demo để xem trước giao diện
npm run seed

# 5. Chạy server
npm start
```

Mặc định server chạy ở `http://localhost:3000`. Lần chạy đầu tiên, hệ thống sẽ **tự động tạo**
file database (`data/app.db`) và **tự động tạo tài khoản Admin mặc định** — không cần thao tác
thủ công gì thêm.

Muốn chạy ở môi trường phát triển (hot reload) khi cần chỉnh sửa code: `npm run dev`.

## 4. Biến môi trường (`.env`)

| Biến | Mô tả |
|---|---|
| `DATABASE_PATH` | Đường dẫn file database SQLite. Mặc định `./data/app.db`. |
| `JWT_SECRET` | Chuỗi bí mật ký cookie đăng nhập Admin. **Bắt buộc đổi sang chuỗi ngẫu nhiên khác** trước khi đưa lên môi trường thật (production). |
| `ADMIN_DEFAULT_EMAIL` / `ADMIN_DEFAULT_PASSWORD` | Tài khoản Admin được tự tạo khi khởi động lần đầu (nếu chưa có tài khoản nào). Đổi mật khẩu này ngay sau lần đăng nhập đầu tiên. |
| `UPLOAD_DIR` | Thư mục lưu ảnh do Admin tải lên (sản phẩm, blog, ảnh khách tải khi thử đồ AI...). Mặc định `./public/uploads`. |
| `AI_TRYON_PROVIDER` | `mock` (demo, không cần API key) / `openai` / `gemini`. Xem mục 5. |
| `OPENAI_API_KEY`, `GEMINI_API_KEY` | API key tương ứng khi dùng provider `openai` hoặc `gemini`. |
| `NEXT_PUBLIC_SITE_URL` | URL công khai của website (dùng cho SEO / metadata). Đổi thành domain thật khi deploy. |

## 5. Cấu hình "Thử đồ AI" (AI Try-On)

Tính năng thử đồ AI hoạt động theo luồng: khách chọn sản phẩm → chọn chất liệu / kiểu dáng / màu
→ tải ảnh toàn thân → thanh toán phí thử đồ (chuyển khoản) → Admin xác nhận thanh toán → hệ thống
tự động gọi AI dựng ảnh khách mặc thử mẫu đã chọn.

Việc "vẽ ảnh" cần một **dịch vụ AI tạo ảnh photorealistic riêng** (bản thân trợ lý AI hỗ trợ xây
dựng website này không tự vẽ ảnh được). Toàn bộ logic gọi API nằm ở 1 file duy nhất:
`src/lib/ai/tryon.ts`, chọn nhà cung cấp qua biến `AI_TRYON_PROVIDER`:

- **`mock`** (mặc định): không gọi API ngoài, dùng ngay để demo toàn bộ luồng hoạt động (ảnh kết
  quả sẽ tạm thời là ảnh gốc khách gửi lên, có ghi chú rõ đây là bản xem trước demo).
- **`openai`**: gọi OpenAI Images API (`gpt-image-1`). Cần điền `OPENAI_API_KEY`.
- **`gemini`**: gọi Google Gemini image API (`gemini-2.5-flash-image`, còn gọi là "Nano Banana").
  Cần điền `GEMINI_API_KEY`.

> ⚠️ **Lưu ý quan trọng:** API của các nhà cung cấp ảnh AI thay đổi khá thường xuyên (endpoint,
> tên model, tham số...). Đoạn code `openai`/`gemini` trong `src/lib/ai/tryon.ts` được viết theo
> tài liệu công khai tại thời điểm xây dựng dự án. **Trước khi dùng thật với API key, hãy kiểm
> tra lại tài liệu mới nhất** và chỉnh sửa nếu nhà cung cấp đã cập nhật:
> - OpenAI: https://platform.openai.com/docs/guides/image-generation
> - Google Gemini: https://ai.google.dev/gemini-api/docs/image-generation
>
> Nếu muốn dùng nhà cung cấp AI khác, chỉ cần thêm 1 hàm `generateXxx()` mới trong file này và
> thêm nhánh tương ứng trong `generateTryOnImage()`.

## 6. Đăng nhập trang quản trị (Admin)

Truy cập `/admin/login` bằng tài khoản mặc định trong `.env` (`ADMIN_DEFAULT_EMAIL` /
`ADMIN_DEFAULT_PASSWORD`). **Hãy đổi mật khẩu ngay sau khi đăng nhập lần đầu** (có thể tạo tài
khoản Admin mới rồi vô hiệu hoá/tài khoản cũ bằng cách sửa trực tiếp trong database, hoặc yêu cầu
bổ sung tính năng đổi mật khẩu nếu cần).

Các mục quản trị chính:

| Mục | Đường dẫn | Chức năng |
|---|---|---|
| Dashboard | `/admin` | Tổng quan đơn hàng, yêu cầu thử đồ, lịch hẹn |
| Sản phẩm | `/admin/san-pham` | Thêm/sửa/xoá áo cưới, vest — ảnh, giá, mô tả, chất liệu/kiểu/màu/size |
| Danh mục / Chất liệu / Kiểu dáng / Màu sắc / Kích thước | `/admin/danh-muc`, `/admin/chat-lieu`, `/admin/kieu-dang`, `/admin/mau-sac`, `/admin/kich-thuoc` | Quản lý các tuỳ chọn dùng chung cho sản phẩm — cũng là "nguyên liệu" mô tả khi AI dựng ảnh thử đồ |
| Đơn hàng | `/admin/don-hang` | Xem chứng từ chuyển khoản, xác nhận thanh toán, cập nhật trạng thái giao hàng |
| Yêu cầu thử đồ AI | `/admin/thu-do-ai` | Xác nhận thanh toán để hệ thống tự dựng ảnh AI, xem/tạo lại kết quả |
| Lịch hẹn | `/admin/lich-hen` | Xác nhận lịch hẹn, đánh dấu đã đặt cọc |
| Khách hàng | `/admin/khach-hang` | Thông tin liên hệ + lịch sử mua hàng/thử đồ/lịch hẹn của từng khách |
| Liên hệ | `/admin/lien-he` | Tin nhắn từ form liên hệ trên website |
| Bài viết Blog | `/admin/blog`, `/admin/blog/danh-muc` | Viết bài chuẩn SEO (H2/H3, chèn ảnh, mục lục tự động), quản lý chủ đề |
| Giao diện website | `/admin/giao-dien` | Logo, favicon, màu sắc, thông tin liên hệ, tài khoản ngân hàng nhận chuyển khoản, phí ship/thử đồ/đặt cọc, nội dung trang chủ |

## 7. Dữ liệu mẫu (`npm run seed`)

Lệnh `npm run seed` (file `scripts/seed.mjs`) nạp sẵn: danh mục, chất liệu, kiểu dáng, màu sắc,
size, 10 sản phẩm mẫu (6 áo cưới + 4 vest), 4 chủ đề & 6 bài blog viết theo chuẩn SEO, cùng vài
khách hàng/đơn hàng/lịch hẹn/yêu cầu thử đồ minh hoạ — giúp xem trước giao diện đầy đủ ngay sau
khi cài đặt.

- Lệnh này **an toàn khi chạy nhiều lần** — nếu database đã có sản phẩm, lệnh sẽ tự bỏ qua để
  tránh tạo trùng lặp.
- **Ảnh sản phẩm/blog trong dữ liệu mẫu là ảnh placeholder** (dùng dịch vụ placehold.co theo đúng
  màu thương hiệu) vì chưa có ảnh chụp sản phẩm thật — hãy thay bằng ảnh thật qua
  **Admin > Sản phẩm** (và Admin > Blog) trước khi vận hành chính thức.
- Nếu **không** muốn dùng dữ liệu mẫu (bắt đầu với database trống hoàn toàn), chỉ cần bỏ qua bước
  `npm run seed` — hệ thống vẫn hoạt động bình thường, bạn tự thêm sản phẩm/bài viết đầu tiên
  trong Admin.
- Muốn xoá dữ liệu mẫu để làm lại từ đầu: xoá file `data/app.db` (và thư mục `public/uploads` nếu
  đã upload ảnh thật) rồi chạy lại từ bước cài đặt.

## 8. Triển khai lên hosting (VPS / Node hosting)

Các bước gợi ý cho một VPS Linux (Ubuntu) — điều chỉnh tương tự nếu dùng hosting Node.js khác:

```bash
# 1. Cài Node.js >= 22.5 trên máy chủ (ví dụ dùng nvm)
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.1/install.sh | bash
nvm install 22

# 2. Copy toàn bộ mã nguồn dự án lên máy chủ, rồi:
cd bridal-atelier
npm install
cp .env.example .env   # rồi chỉnh sửa: JWT_SECRET, ADMIN_DEFAULT_PASSWORD, NEXT_PUBLIC_SITE_URL...
npm run build

# 3. (Tuỳ chọn) nạp dữ liệu mẫu lần đầu
npm run seed

# 4. Dùng một process manager để giữ server chạy liên tục & tự khởi động lại khi lỗi
npm install -g pm2
pm2 start npm --name "tomq-bridal" -- start
pm2 save
pm2 startup   # làm theo hướng dẫn để pm2 tự chạy lại sau khi reboot máy chủ
```

Sau đó đặt **Nginx** (hoặc Caddy) làm reverse proxy trỏ domain thật vào cổng Next.js (mặc định
`3000`), ví dụ cấu hình Nginx:

```nginx
server {
    listen 80;
    server_name tomqbridal.com www.tomqbridal.com;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Dùng `certbot` (Let's Encrypt) để bật HTTPS miễn phí:

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d tomqbridal.com -d www.tomqbridal.com
```

### Sao lưu dữ liệu (backup)

Toàn bộ dữ liệu của website nằm trong 2 nơi — **hãy sao lưu định kỳ**:

- `data/app.db` — toàn bộ database (sản phẩm, đơn hàng, khách hàng, bài viết, cấu hình...)
- `public/uploads/` — toàn bộ ảnh đã tải lên (sản phẩm, blog, chứng từ chuyển khoản, ảnh khách
  thử đồ...)

### Cập nhật (deploy) phiên bản mới của code sau này

```bash
git pull            # hoặc copy mã nguồn mới lên
npm install
npm run build
pm2 restart tomq-bridal
```

Database và ảnh upload nằm ngoài mã nguồn nên không bị mất khi cập nhật code.

## 9. Cấu trúc thư mục chính

```
db/schema.sql            Toàn bộ cấu trúc database (SQLite)
scripts/seed.mjs          Script nạp dữ liệu mẫu
src/app/                  Các trang website (App Router) — trang chủ, sản phẩm, giỏ hàng,
                           thanh toán, thử đồ AI, blog, và toàn bộ trang /admin
src/app/actions/          Server Actions xử lý form (public.ts, admin.ts, admin-auth.ts)
src/lib/repo/             Lớp truy vấn database theo từng nhóm dữ liệu
src/lib/ai/tryon.ts        Kết nối dịch vụ AI tạo ảnh thử đồ (xem mục 5)
src/components/           Component dùng chung (site/ cho trang công khai, admin/ cho trang quản trị)
public/uploads/           Ảnh do Admin / khách hàng tải lên (tự tạo khi chạy)
data/app.db                File database SQLite (tự tạo khi chạy lần đầu)
```

## 10. Lưu ý trước khi vận hành chính thức

- Đổi `JWT_SECRET` và mật khẩu Admin mặc định.
- Thay toàn bộ ảnh placeholder (sản phẩm, blog, banner trang chủ) bằng ảnh thật qua Admin.
- Kiểm tra lại thông tin liên hệ, tài khoản ngân hàng nhận chuyển khoản, phí ship/thử đồ/đặt cọc
  trong **Admin > Giao diện website**.
- Nếu dùng thử đồ AI thật (không phải chế độ demo `mock`), nhớ đọc kỹ lưu ý ở mục 5 trước khi bật
  `OPENAI_API_KEY`/`GEMINI_API_KEY`, và theo dõi chi phí sử dụng API vì mỗi lần dựng ảnh đều tốn
  phí từ nhà cung cấp AI.
